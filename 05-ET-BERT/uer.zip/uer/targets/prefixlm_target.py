import torch
import torch.nn as nn
from uer.targets import *


class PrefixlmTarget(LmTarget):
    pass
